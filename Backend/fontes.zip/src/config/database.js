import mysql from 'mysql';

// Conexao com o banco
const db = mysql.createPool({
    host: "localhost",
    user: "root",
    password: "hksse568a",
    database: "meu_mercado"
});


export default db;